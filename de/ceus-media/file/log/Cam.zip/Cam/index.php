<?php
$filename	= "cam.jpg";
if( file_exists( $filename ) )
{
	if( filemtime( $filename ) >= time() -10 )
		include( "cam.html" );
	else
		include( "no_cam.html" );
}
?>