<?
/**
* associative Matrix
*
* Assoziative Matrix.
*
* @package		adt
* @subpackage	matrix
* @extends		Matrix
* @author		Christian W�rker <Christian.Wuerker@CeuS-Media.de>
* @version		1.0
**/
/**
* associative Matrix
*
* Assoziative Matrix.
*
* @package		adt
* @subpackage	matrix
* @extends		Matrix
* @author		Christian W�rker <Christian.Wuerker@CeuS-Media.de>
* @version		1.0
**/
class AssocMatrix extends Matrix
{
	var $x_assoc = array ();
	var $y_assoc = array ();

	var $assoc_x = array ();
	var $assoc_y = array ();


	/**
	* Constructor.
	*
	* @access	private
	* @return	void
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function AssocMatrix ()
	{
		$this->Matrix (0,0,0);
	}


	/**
	* Add associative name and get x axis key.
	*
	* @access	public
	* @param	string	$assoc		associative name for a new x axis key
	* @return	int
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function addAssocX($assoc)
	{
		$key = sizeof($this->assoc_x);
		$this->assoc_x[$assoc] = $key;
		$this->x_assoc[$key] = $assoc;
		$this->max_x++;
		$this->initMatrix ($this->max_x, $this->max_y);
		return $key;
	}


	/**
	* Add associative name and get y axis key.
	*
	* @access	public
	* @param	string	$assoc		associative name for a new y axis key
	* @return	int
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function addAssocY($assoc)
	{
		$key = sizeof($this->assoc_y);
		$this->assoc_y[$assoc] = $key;
		$this->y_assoc[$key] = $assoc;
		$this->max_y++;
		$this->initMatrix ($this->max_x, $this->max_y);
		return $key;
	}


	/**
	* Add a matrix value by associative names.
	*
	* @access	public
	* @param	string	$assoc_x	associative name for a new x axis key
	* @param	string	$assoc_y	associative name for a new y axis key
	* @param	string	$value		new matrix value
	* @return	int
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function addValueAssoc ($assoc_x, $assoc_y, $value)
	{
		$x = $this->getXByAssoc ($assoc_x);
		if ($x < 0) $x = $this->addAssocX ($assoc_x);
		$y = $this->getYByAssoc ($assoc_y);
		if ($y < 0) $y = $this->addAssocY ($assoc_y);
		$this->add ($x, $y, $value);
	}


	/**
	* Get associative name of x axis element.
	*
	* @access	public
	* @param	int		$x			x axis key of associative name
	* @return	string
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function getAssocByX ($x)
	{
		if (isset($this->x_assoc[$x])) return $this->x_assoc[$x];
		return false;
	}

	/**
	* Get associative name of y axis element.
	*
	* @access	public
	* @param	string	$y			y axis key of associative name
	* @return	string
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function getAssocByY ($y)
	{
		if (isset($this->y_assoc[$y])) return $this->y_assoc[$y];
		return false;
	}


	/**
	* Get matrix value by associative names.
	*
	* @access	public
	* @param	string	$assoc_x	associative name for a new x axis key
	* @param	string	$assoc_y	associative name for a new y axis key
	* @return	int
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function getValueByAssoc ($assoc_x, $assoc_y)
	{
		$x = $this->getXByAssoc ($assoc_x);
		$y = $this->getYByAssoc ($assoc_y);
		return $this->getValue ($x, $y);
	}

	/**
	* Get x axis element of associative name.
	*
	* @access	public
	* @param	string	$assoc		associative name for a new x axis key
	* @return	int
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function getXByAssoc ($assoc)
	{
		if (isset($this->assoc_x[$assoc])) return $this->assoc_x[$assoc];
		return -1;
	}

	/**
	* Get y axis element of associative name.
	*
	* @access	public
	* @param	string	$assoc		associative name for a new y axis key
	* @return	int
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function getYByAssoc ($assoc)
	{
		if (isset($this->assoc_y[$assoc])) return $this->assoc_y[$assoc];
		return -1;
	}

	/**
	* Output as 2 dimensional array.
	*
	* @access	public
	* @return	array
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function toArray()
	{
		$array = array ();
		for ($i=0; $i <= $this->max_x; $i++)
		{
			$line = array ();
			for ($j=0; $j <= $this->max_y ;$j++)
			{
				$line[$this->getAssocByY($j)] = $this->matrix [$i][$j];
			}
			$array[$this->getAssocByX($i)] = $line;
		}
		return $array;
	}

	/**
	* Output as Table in HTML.
	*
	* @access	public
	* @return	string
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function toTable ()
	{
		$code = "<table class='filledframe'>";
		$code .= "     <colgroup><col width='100'>".str_repeat ("<col width='20'>", $this->max_y+1)."</colgroup>";

		$code .= "<tr><td></td>";
		for ($j=0; $j <= $this->max_y ;$j++) $code .= "<td>".$this->getAssocByY ($j)."</td>";
		$code .= "</tr>";


		for ($i=0; $i <= $this->max_x; $i++)
		{
			$code .= "<tr><td>".$this->getAssocByX($i)."</td>";
			for ($j=0; $j <= $this->max_y ;$j++)
			{
				$code .= "<td>".$this->matrix [$i][$j]."</td>";
			}
			$code .= "</tr>";
		}
		$code .= "</table>";
		return $code;
	}
}
?>