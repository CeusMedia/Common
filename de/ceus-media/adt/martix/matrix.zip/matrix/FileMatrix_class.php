<?
/**
* File Matrix
*
* Matrix mit Datenhaltung in Datei.
*
* @package		adt
* @subpackage	matrix
* @extends		Matrix
* @author		Christian W�rker <Christian.Wuerker@CeuS-Media.de>
* @version		1.0
**/
/**
* File Matrix
*
* Matrix mit Datenhaltung in Datei.
*
* @package		adt
* @subpackage	matrix
* @extends		Matrix
* @author		Christian W�rker <Christian.Wuerker@CeuS-Media.de>
* @version		1.0
**/
class FileMatrix extends Matrix
{
	/** @var string	$filename	filename of matrix **/
	var $filename;

	/**
	* Constructor.
	*
	* @param	string	$filename		filename of matrix
	* @access	private
	* @return	void
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function FileMatrix ($filename)
	{
		$this->Matrix ();
		$this->filename = $filename;
	}

	/**
	* Loading matrix from file.
	*
	* @param	string	$filename		filename of matrix
	* @access	public
	* @return	bool
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function loadMatrix ()
	{
		if (file_exists ($this->filename))
		{
			$x = 0;
			$fcont = file($this->filename);
			foreach ($fcont as $line)
			{
				$y=0;
				$values = explode ("|", trim($line));
				foreach ($values as $value)
				{
					$this->add($x, $y, $value);
					$y++;
				}
				$x++;
			}
		}
		else return false;
	}


	/**
	* Saving matrix to file.
	*
	* @access	public
	* @return	void
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function saveMatrix ()
	{
		$fp = fopen ($this->filename, "w");
		for ($i=0; $i <= $this->max_x; $i++)
		{
			$line = array ();
			for ($j=0; $j <= $this->max_y ;$j++)
			{
				$line [] = $this->matrix [$i][$j];
			}
			fputs($fp, implode ("|", $line)."\n");
		}
		fclose ($fp);
	}
}
?>