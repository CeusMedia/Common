<?
/**
* Matrix
*
* @package		adt
* @subpackage	matrix
* @extends		Matrix
* @author		Christian W�rker <Christian.Wuerker@CeuS-Media.de>
* @version		1.0
**/
/**
* Matrix
*
* @package		adt
* @subpackage	matrix
* @extends		Matrix
* @author		Christian W�rker <Christian.Wuerker@CeuS-Media.de>
* @version		1.0
**/
class Matrix
{
	var $matrix;
	var $max_x;
	var $max_y;
	//var $current_row;
	//var $current_col;


	/**
	* Constructor.
	*
	* @param	string	$filename		filename of matrix
	* @access	private
	* @return	void
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function Matrix ($max_x = -1, $max_y = -1, $init = 0)
	{
		$this->max_x = $max_x;
		$this->max_y = $max_y;
		$this->init = $init;
		$this->initMatrix ($max_x, $max_y);
	}


	/**
	* Initiate matrix by creating an array.
	*
	* @param	int		$to_x			max x axis keys
	* @param	int		$to_y			max y axis keys
	* @access	public
	* @return	void
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function initMatrix ($to_x, $to_y)
	{
		for ($i=0; $i <= $to_x; $i++)
		{
			for ($j=0; $j <= $to_y; $j++)
			{
				if (!isset($this->matrix [$i][$j])) $this->matrix [$i][$j] = $this->init;
			}
		}
		if ($to_x > $this->max_x) $this->max_x = $to_x;
		if ($to_x > $this->max_y) $this->max_y = $to_y;
	}


	/**
	* Adding a matrix value by axis keys.
	*
	* @param	int		$x			x axis key
	* @param	int		$y			y axis key
	* @param	string	$value		new matrix value
	* @access	public
	* @return	void
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function add ($x, $y, $value)
	{
		if ($this->max_x < $x || $this->max_y < $y) $this->initMatrix ($x, $y);
		$this->matrix [$x][$y] = $value;
	}


	/**
	* Getting whole row by x axis key.
	*
	* @param	int		$x			x axis key
	* @access	public
	* @return	array
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function getRow ($x)
	{
		foreach ($this->matrix[$x] as $value)
		{
			$array[] = $value;
		}
		return $array;
	}


	/**
	* Getting whole column of y axis key.
	*
	* @param	int		$y			y axis key
	* @access	public
	* @return	array
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function getColumn ($y)
	{
		foreach ($this->matrix as $row)
		{
			$array[] = $row[$y];
		}
		return $array;
	}


	/**
	* Getting matrix value of axis keys.
	*
	* @param	int		$x			x axis key
	* @param	int		$y			y axis key
	* @access	public
	* @return	void
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function getValue ($x, $y)
	{
		return $this->matrix [$x][$y];
	}


	/**
	* Output as array.
	*
	* @access	public
	* @return	array
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function toArray()
	{
		$array = array ();
		for ($i=0; $i <= $this->max_x; $i++)
		{
			$line = array ();
			for ($j=0; $j <= $this->max_y ;$j++)
			{
				$line[] = $this->matrix [$i][$j];
			}
			$array[] = $line;
		}
		return $array;
	}


	/**
	* Output as table in HTML.
	*
	* @access	public
	* @return	string
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function toTable ()
	{
		$code = "<table class='filledframe'>";
		$code .= "     <colgroup>".str_repeat ("<col width='20'>", $this->max_y+1)."</colgroup>";

		for ($i=0; $i <= $this->max_x; $i++)
		{
			$code .= "<tr>";
			for ($j=0; $j <= $this->max_y ;$j++)
			{
				$code .= "<td>".$this->matrix [$i][$j]."</td>";
			}
			$code .= "</tr>";
		}
		$code .= "</table>";
		return $code;
	}
}
?>