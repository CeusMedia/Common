<?
/**
* associative File Matrix
*
* Assoziative Matrix mit Datenhaltung in Datei.
*
* @package		adt
* @subpackage	matrix
* @extends		AssocMatrix
* @author		Christian W�rker <Christian.Wuerker@CeuS-Media.de>
* @version		1.0
**/
/**
* associative File Matrix
*
* Assoziative Matrix mit Datenhaltung in Datei.
*
* @package		adt
* @subpackage	matrix
* @extends		AssocMatrix
* @author		Christian W�rker <Christian.Wuerker@CeuS-Media.de>
* @version		1.0
**/
class AssocFileMatrix extends AssocMatrix
{
	/** @var string	$filename	filename of matrix **/
	var $filename;


	/**
	* Constructor.
	*
	* @param	string	$filename		filename of matrix
	* @access	private
	* @return	void
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function AssocFileMatrix ($filename)
	{
		$this->AssocMatrix ();
		$this->filename = $filename;
	}


	/**
	* Loading matrix from file.
	*
	* @param	string	$filename		filename of matrix
	* @access	public
	* @return	bool
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function loadMatrix ()
	{
		if (file_exists ($this->filename))
		{
			$x = -1;
			$fp = fopen ($this->filename, "r");
			$fcont = explode ("\n", trim(fread ($fp, filesize($this->filename))));
			foreach ($fcont as $line)
			{
				if ($x < 0)
				{
					foreach (explode ("|", trim($line)) as $assoc_y) $this->addAssocY ($assoc_y);
				}
				else
				{
					$y=-1;
					foreach (explode ("|", trim($line)) as $value)
					{
						if ($y < 0) $this->addAssocX ($value);
						else $this->add($x, $y, $value);
						$y++;
					}
				}
				$x++;
			}
			return true;
		}
		else return false;
	}


	/**
	* Saving matrix to file.
	*
	* @access	public
	* @return	void
	* @author	Christian W�rker <Christian.Wuerker@CeuS-Media.de>
	* @version	1.0
	**/
	function saveMatrix ()
	{
		$fp = fopen ($this->filename, "w");
		$assoc_y = array ();
		for ($j=0; $j <= $this->max_y; $j++) $assoc_y[] = $this->getAssocByY($j);
		fputs ($fp, implode ("|", $assoc_y)."\n");

		for ($i=0; $i <= $this->max_x; $i++)
		{
			$line = array ($this->getAssocByX ($i));
			for ($j=0; $j <= $this->max_y ;$j++)
			{
				$line [] = $this->matrix [$i][$j];
			}
			fputs($fp, implode ("|", $line)."\n");
		}
		fclose ($fp);
	}
}
?>